<script setup>
import { ref, computed } from 'vue';

const tasks = ref([]); 
const newTask = ref(''); 
const editingIndex = ref(null); 
const editingTaskText = ref('');
const filter = ref('all'); 
const taskPriority = ref('medium'); 


const addTask = () => {
  if (newTask.value.trim() !== '') {
    tasks.value.push({ text: newTask.value, completed: false, priority: taskPriority.value });
    newTask.value = ''; 
    taskPriority.value = 'medium'; 
  }
};

// Function to remove a task
const removeTask = (index) => {
  tasks.value.splice(index, 1);
};

// Function to toggle task completion
const toggleTaskCompletion = (task) => {
  task.completed = !task.completed;
};

// Function to start editing a task
const startEditing = (index) => {
  editingIndex.value = index;
  editingTaskText.value = tasks.value[index].text;
};

// Function to save the edited task
const saveEditedTask = () => {
  if (editingTaskText.value.trim() !== '') {
    tasks.value[editingIndex.value].text = editingTaskText.value;
    cancelEditing();
  }
};

// Function to cancel editing
const cancelEditing = () => {
  editingIndex.value = null;
  editingTaskText.value = '';
};

// Function to clear all completed tasks
const clearCompletedTasks = () => {
  tasks.value = tasks.value.filter((task) => !task.completed);
};

// Computed property to filter tasks
const filteredTasks = computed(() => {
  if (filter.value === 'completed') return tasks.value.filter((task) => task.completed);
  if (filter.value === 'pending') return tasks.value.filter((task) => !task.completed);
  return tasks.value; 
});
</script>




<template>
  <header>
    <img alt="Vue logo" class="logo" src="./assets/logo.svg" width="125" height="125" />
    <h1>To-Do List</h1>
  </header>

  <main>
    <!-- Input Section -->
    <div class="input-section">
      <input 
        v-model="newTask" 
        type="text" 
        placeholder="Add a new task" 
      />
      <select v-model="taskPriority">
        <option value="high">High Priority</option>
        <option value="medium">Medium Priority</option>
        <option value="low">Low Priority</option>
      </select>
      <button @click="addTask">Add Task</button>
    </div>

    <!-- Filter Section -->
    <div class="filter-section">
      <button @click="filter = 'all'" :class="{ active: filter === 'all' }">All</button>
      <button @click="filter = 'completed'" :class="{ active: filter === 'completed' }">Completed</button>
      <button @click="filter = 'pending'" :class="{ active: filter === 'pending' }">Pending</button>
      <button @click="clearCompletedTasks">Clear Completed</button>
    </div>

    <!-- Task List -->
    <ul class="task-list">
      <li 
        v-for="(task, index) in filteredTasks" 
        :key="index" 
        :class="{ completed: task.completed, [task.priority]: true }"
      >
        <!-- Check if the task is being edited -->
        <div v-if="editingIndex === index">
          <input 
            v-model="editingTaskText" 
            type="text" 
          />
          <button @click="saveEditedTask">Save</button>
          <button @click="cancelEditing">Cancel</button>
        </div>

        <div v-else>
          <span @click="toggleTaskCompletion(task)">{{ task.text }}</span>
          <button @click="startEditing(index)">Edit</button>
          <button @click="removeTask(index)">Remove</button>
        </div>
      </li>
    </ul>
  </main>
</template>


<style scoped>
header {
  text-align: center;
  margin-bottom: 2rem;
}

.logo {
  display: block;
  margin: 0 auto;
}

h1 {
  font-size: 1.8rem;
  margin-top: 0.5rem;
}

.input-section {
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

input {
  width: 50%;
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
}

select {
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  padding: 0.5rem 1rem;
  border: none;
  background-color:  #c44e85;
  color: rgb(42, 6, 110);
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #d8a4bc;
}

.filter-section {
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.filter-section button {
  padding: 0.5rem;
  border: 1px solid #ccc;
  background-color: #eee;
  border-radius: 4px;
  cursor: pointer;
}

.filter-section button.active {
  background-color: #c44e85;
  color: white;
}

.task-list {
  list-style: none;
  padding: 0;
  max-width: 600px;
  margin: 0 auto;
}

.task-list li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin-bottom: 0.5rem;
}

.task-list li.completed span {
  text-decoration: line-through;
  color: rgb(247, 242, 242);
  cursor: pointer;
}

.task-list li span {
  flex-grow: 1;
  cursor: pointer;
}

/* Priority styles */
.task-list li.high {
  border-left: 5px solid red;
}

.task-list li.medium {
  border-left: 5px solid orange;
}

.task-list li.low {
  border-left: 5px solid green;
}
</style>
